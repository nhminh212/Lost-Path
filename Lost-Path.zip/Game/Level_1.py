import sys
import pygame as pg
from Data import main

if __name__ == '__main__':
    main.Main()
    pg.quit()
    sys.exit()
